package human11.domain.dao;

public interface UserInfoDao {
	public void insertInfo(UserInfo userInfo);
	public void deleteInfo(UserInfo userInfo);
	public void searchInfo(UserInfo userInfo);
}
