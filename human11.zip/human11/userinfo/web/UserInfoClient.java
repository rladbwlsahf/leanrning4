package human11.userinfo.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import human11.domain.dao.UserInfo;
import human11.domain.dao.UserInfoDao;
import human11.domain.dao.mysql.MySQLDao;
import human11.domain.dao.oracle.OracleDao;

public class UserInfoClient {

	public static void main(String[] args) throws IOException {
		UserInfo uinfo 
			= new UserInfo("human", "12345", "KANG");
//		uinfo.setUserPassword("7890");
		
		FileInputStream fis 
			= new FileInputStream("D:\\AI_Class\\J2SE_FILE_2\\EX04\\src\\human11\\userinfo\\web\\conf");
		
		Properties prop = new Properties();
		prop.load(fis);
		
		String dbType = prop.getProperty("DBTYPE");
		// dbType ==> "ORACLE" 또는 "MYSQL"
		
		UserInfoDao userInfoDao; 
		if (dbType.equals("ORACLE")) {
			userInfoDao = new OracleDao();
		}
		else {
			userInfoDao = new MySQLDao();
		}
		userInfoDao.insertInfo(uinfo);
		userInfoDao.searchInfo(uinfo);
		userInfoDao.deleteInfo(uinfo);
	}
}
